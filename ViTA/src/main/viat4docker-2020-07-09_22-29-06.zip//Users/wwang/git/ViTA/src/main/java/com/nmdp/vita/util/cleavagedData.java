package com.nmdp.vita.util;

public class cleavagedData {
    public  String seq;
    public String cle;

    public cleavagedData(String seq, String cle){
        this.seq = seq;
        this.cle = cle;
    }
}
